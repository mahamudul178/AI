<?php

$result_str=$result="";
if(isset($_POST["submit"])){
    $units=$_POST['units'];
    if(!empty($units)){
        $result=calculate_billl($units);
        $result_str='Total amount of '. $units.' units = '.$result.' Taka';
    }
}
        function calculate_billl($units) {
            
        if ($units <= 50) {
            $bill = $units * 3.50;
            return $bill;
        } elseif ($units <= 100) {
            $bill = 50 * 3.50 + ($units - 50) * 4.00;
            return $bill;
        } elseif ($units <= 200) {
            $bill = 50 * 3.50 + 50 * 4.00 + ($units - 100) * 5.20;
            return $bill;
        } else {
            $bill = 50 * 3.50 + 50 * 4.00 + 100 * 5.20 + ($units - 200) * 6.50;
            return $bill;
        }

        }

    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electricity Bill</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <h1>Calculate Electricity Bill</h1>
        <form class="form" action="" method="POST">
        <label for="unit">Units:</label>
        <input type="text" name="units" id="unit" placeholder="Please enter no. of Units">
        <button name="submit">Submit</button><br>
        <?php  echo $result_str ?>
        </form>
    </div>
</body>
</html>