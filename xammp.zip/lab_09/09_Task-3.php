<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "Student"; 

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert sample data
$sql = "INSERT INTO Semester_Reg (ID,Name, Session, Ph_Num, City, Gender) VALUES (101,'Rana', '2017-2018', '01767890', 'Pabna', 'Female')";
if ($conn->query($sql) === TRUE) {
    echo "Sample data inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
