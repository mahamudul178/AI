<?php
$connect=mysqli_connect("localhost","root","","Student");

if(isset($_POST["insert"]))
{
	$id =$_POST["id"];
	$name=$_POST["name"];
	$sess=$_POST["session"];
	$phone=$_POST["ph_number"];
	$city=$_POST["city"];
	$gender=$_POST["gender"];
	$insert="insert into semester_reg(ID,Name,Session,Ph_Num,City, Gender) values('$id','$name','$sess', '$phone', '$city', '$gender')";
	$result=mysqli_query($connect,$insert);
	if($result==1)
	{
        echo '<div class="alert alert-success" role="alert">
        <strong>Success </strong> Successfully insert a record!
     </div>';
	}
	else
	{
		echo"Unsucess";
	}
}  //Insert end

//Delete start
if(isset($_POST["delete"]))
{
	$id =$_POST["id"];
	$name=$_POST["name"];
	$sess=$_POST["session"];
	$delete="delete from semester_reg where ID='$id'and Name='$name' and Session='$sess'";
	$result=mysqli_query($connect,$delete);
	if($result==1)
	{
        echo '<div class="alert alert-success" role="alert">
        <strong>Success </strong> Successfully delete your record!
     </div>';
	}
	else
	{
		echo"Unsucess";
	}
} //------Delete end-

//update start
if(isset($_POST["update"]))
{
	$id =$_POST["id"];
	$name=$_POST["name"];
	$sess=$_POST["session"];
	$phone=$_POST["ph_number"];
	$city=$_POST["city"];
	$gender=$_POST["gender"];
	$insert="update semester_reg  set Name='$name',Session='$sess',Ph_Num='$phone', City='$city',Gender='$gender' where ID='$id'";
	$result=mysqli_query($connect,$insert);
	if($result==1)
	{
        echo '<div class="alert alert-success" role="alert">
        <strong>Success </strong> Successfully updated your record!
     </div>';
	}
	else
	{
		echo"Unsucess";
	}
}//-update end--

//show data start
if(isset($_POST["select"])){

$query="SELECT * FROM semester_reg";
$result=mysqli_query($connect,$query);
if($result==true){
	echo "All  Registered Students List <br>";
echo "<table cellpadding=10 border='1'>
<tr>
<th>ID</th> 
<th>Name</th>
<th>Session</th>
<th>Phone Number</th>
<th>City</th>
<th>Gender</th>
</tr>";
 if(mysqli_num_rows($result) > 0)
{
while($row = mysqli_fetch_array($result))
{
	
echo "<tr>";
echo "<td style='color:black'>" . $row['ID'] ."</td>";
echo "<td style='color:black'>" . $row['Name'] . "</td>";
echo "<td style='color:black'>" . $row['Session'] . "</td>";
echo "<td style='color:black'>" . $row['Ph_Num'] . "</td>";
echo "<td style='color:black'>" . $row['City'] . "</td>";
echo "<td style='color:black'>" . $row['Gender'] . "</td>";
echo "</tr>";
}
echo "</table>";

}
} else
{
	echo "No record found!";
}
}
//end of show data

?>
<html>
<head>
	<title>Student Registration Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body {
            text-align: center;
            font-size: 25px;
            /* background-color: #f2f2f2; */
            /* background-image:url("lab_09.webp"); */
            background:navajowhite;
            
        }
        .container{
            margin-top: 50px;
            /* margin: auto; */
            background-color: rosybrown;
            width: 560px;
            height: 470px;
            border: 1px solid ;
            border-radius: 10px;
        
        }

        input, select, textarea {
            font-size: 17px;
            padding: 4px;
        }

        table {
            margin: auto;
            font-size: 18px;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
        }

        th {
            background-color: #f2f2f2;
        }

        h2 {
            font-size: 30px;
        }

        form {
            margin: 20px;
        }

        label {
            color: red;
        }
        .in1
        {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 17px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
        }
        .in2{
            background-color: red;
            color: white;
            border: none;
            padding: 8px 17px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
        }
        .in3{
            background-color:yellowgreen;
            color: white;
            border: none;
            padding: 8px 17px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
        }
        .in4{
            background-color:goldenrod;
            color: white;
            border: none;
            padding: 8px 17px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: rgb(0, 5, 8);
        }
        .note{
            background-color: yellowgreen;
            padding: 20px;
            border:1px solid;
            border-radius: 5px;
            
        }
    </style>

</head>
<body>
        <div class="container">
        <h2>Semester Registration Form </h2>
<form method="post" action="">
<table border="0" style="text-align:left" >
        <tr>
           <th >ID</th>
           <td><input type="text" name="id" placeholder="Enter your ID" required></td>
         </tr>
		 <tr>
           <th>Name</th>
        <td><input type="text" name="name" placeholder="Enter your Name"  required></td>
         </tr>
         <tr>
           <th>Session</th>
           <td><input type="text" name="session" placeholder="Enter session" required></td>
         </tr>
         <tr>
           <th >Phone Number</th>
           <td><input type="text" name="ph_number" placeholder="Enter the Number" ></td>
         </tr>
		 <tr>
           <th >City</th>
           <td><input type="text" name="city" value="" placeholder="City name" ></td>
		 </tr>
		 <tr>
           <th>Gender</th>
           <td><input type="radio" name="gender" value="Male" checked> Male
                <input type="radio" name="gender" value="Female"> Female
            </td>
		 </tr>
		 <tr> 
		 	<td colspan="4">
		 		<input class="in1" type="submit" name="insert" value="Insert">
                <input class="in2" type="submit" name="delete" value="Delete">
                <input class="in3" type="submit" name="update" value="Update">
                <input class="in4" type="submit" name="select" value="Show">
		 	</td>
		 </tr>
		 </table> 

		 <br>
        <label style="color:red">N.B. </label>
        <div class="note">
                <p>1. To Insert Some sample data into Semester Registration Table</p>
                <p>2. To show all records of Semester_Reg table.</p>
                <p>3. To delet sample data from Semester_Reg table </p>
                <p>4. To Update one sample data of Semester_Reg table except ID Number.</p>
              
        </div>
</form>

        </div>
</body>
</html>