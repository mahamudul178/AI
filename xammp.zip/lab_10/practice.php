
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<style type="text/css">
		body{
			background-color: lavender;
		}
		.container{
			background-color:ivory;
			width: 620px;
			height: 420px;
			border: 1px solid;
			border-radius: 5px;
			margin-top: 20px;
		
		}
		table
		{
			margin: auto;
			font-size: 25px;
			text-align: left;
		}
		input
		{
			font-size: 20px;
			width: 100%;
		}
		.insert
		{
			width: 100%;
			font-size: 20px;
			background-color: green;
			border: 1px solid;
			border-radius: 5px;
			padding: 5px;
			color: white;
			cursor: pointer;
		}
		.insert:hover{
			background-color:blue;
		}
		.select:hover{
			background-color: blue;
		}
		.delete:hover{
			background-color: blue;
		}
		.select{
			width: 100%;
			font-size: 20px;
			background-color:olivedrab;
			border: 1px solid;
			border-radius: 5px;
			padding: 5px;
			color: white;
			cursor: pointer;
		}
		.delete{
			width: 100%;
			font-size: 20px;
			background-color: red;
			border: 1px solid;
			border-radius: 5px;
			padding: 5px;
			color: white;
			cursor: pointer;

		}
		.td1{
			border: 1px solid black;
			border-collapse: collapse;
			width: 300px;
			margin-top: 5px;
			padding: 0px;
			background-color: #fff;

		}
		.th1{
			background-color:black;
			color: white;

		}
		.tab1{
			margin-top: 20px;
		}
	</style>
</head>
<body>
		<div class="container">
		<h1 style="text-align:center;">Programmer Registration Form</h1>

<form method="post" action="" enctype="multipart/form-data">
	<table border="0">
		<tr>
			<th>ID:</th>
			<td colspan="2"><input type="text"name="id" required> </td>
		</tr>
		<tr>
			<th>Name:</th>
			<td colspan="2"> <input type="text"name="name"></td>
		</tr>
		<tr >
			<th colspan="3"><img id="image_change" src="images/man_icon.jpg" height="160px" width="100%" border="1"></th>
		</tr>
		<tr> 
			<th >Image:</th>
			<td><input type="file" name="img" id="img_id"onchange="change(event)"></td>
		</tr>
		<tr>
			<th>Password:</th>
			<td colspan="2"><input type="password" name="password" required></td>
		</tr>
		<tr >
			<th><button class="insert" name="insert">Insert</button></th>
			<th><button class="select" name="select">Show</button></th>
			<th><button class="delete" name="delete">Delete</button></th>
		</tr>
		<div class="note">
		<tr>
			<!-- <td colspan="3">
				N.B. 1. To delete a record inter your ID and Password.<br>
				2. To show all records enter your ID and Password.
			</td> -->
		</tr>
		</div>
	</table>
</form>
		</div>



<script>
function change(event)
{
	var output=document.getElementById('image_change');
	output.src=URL.createObjectURL(event.target.files[0]);
}
</script>
</body>
</html>




<?php
$connect=mysqli_connect("localhost","root","","Program");

//Insert start

if(isset($_POST["insert"]))
{
	$id =$_POST["id"];
	$name=$_POST["name"];
	$password=$_POST["password"];
	//image
	$img=$_FILES["img"]["name"];
	$extention=pathinfo($img,PATHINFO_EXTENSION);
	$img_new_name=$id.'.'.$extention;
	
	$pass = md5($password);

	$insert="INSERT INTO Stu_Reg(ID,Name,Image,Password) VALUES ('$id','$name','images/$img', '$pass')";
	$result=mysqli_query($connect,$insert);

        move_uploaded_file($_FILES['img']['tmp_name'], "images/" . $_FILES['img']['name']);
	if($result==1)
	{
		echo '<div class="alert alert-success" role="alert">
        <strong>Success </strong> Successfully Insert your record!
     </div>';
	}
	else
	{
		echo"Unsucess";
	}
} //insert End
//delete start
if(isset($_POST['delete']))
     {
    $id = $_POST['id'];
    $password = $_POST['password'];
     $pass=md5($password);
     $query="SELECT * FROM Stu_Reg where ID = '$id' and Password='$pass'";  
         $result=mysqli_query($connect,$query);
         $row = mysqli_fetch_array($result);
   $query = "DELETE FROM Stu_Reg where ID = '$id' and Password='$pass'";
   $execute = mysqli_query($connect,$query);
   if($execute)
    {
    	//remove image

    	         $image=$row['Image'];
               unlink("$image");
			   echo '<div class="alert alert-success" role="alert">
			   <strong>Success </strong> Successfully Delete your record!
			</div>';
    }
   else
{ 
 echo "Unsucess";
}
}//delete end
//show data from database
if(isset($_POST["select"])){

$query="SELECT * FROM Stu_Reg"; 
$result=mysqli_query($connect,$query);

 if(mysqli_num_rows($result) > 0)
{
?>

 <table class="tab1" cellpadding=10 border=''>
	<tr>
	<th class="th1" >ID</th> 
	<th class="th1" >Name</th>
	<th class="th1" >Image</th>
	</tr>
 <?php
while($row = mysqli_fetch_array($result))
{
?>	
	<tr>
	<td class="td1" style='color:black'><?php echo $row['ID']?></td>
	<td class="td1" style='color:black'><?php echo $row['Name']?></td>
	<td class="td1" style='color:black'> <img width=100px height=80px src="<?php echo $row['Image']?>"></td>
	</tr>
<?php
}

?>
	</table>
<?php
}
else
{
	echo "No Data Found!";
}
}

//end of show database
?>

